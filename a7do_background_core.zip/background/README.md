# A7DO (Born AI) — Background Core (no UI)

This directory contains the **headless** A7DO engine (no `app.py`, no Streamlit). It is meant to be imported by any future UI/runner.

## What this implements

### 1) Sandy’s Law constraint layer
A physics-inspired state machine that turns raw observations into:
- **Trap strength Z** (how “locked” a system is)
- **Entropy export Σ** (how much information/energy can leave)
- **Portal score K** (transition trigger / regime classifier)
- **Trap transitions** (drift → pre-transition → Zeno / modulated regime)

### 2) Square micro-world
A microscopic sandbox where A7DO learns *structure* via:
- persistence
- clustering
- alternating / oscillatory neighborhoods
- phase transitions

### 3) SLED signal interface
A minimal bridge so SLED-style “information rooms” and market/room signals can be treated as just another sensory stream.

### 4) Cognition, memory, and choice
A7DO does:
- pattern extraction (simple, local, transparent)
- persistence scoring
- mind-mapping (graph of concepts)
- decoherence model (when a pattern becomes classical/locked-in)
- emotion as a regulator (not a label)
- action policy that is gated by regime & confidence

## How to use

```bash
python -m a7do_core.tests.smoke
```

This runs a tiny headless loop:
- generates synthetic observations
- updates Z/Σ/K
- commits patterns into memory when persistent
- produces a small action decision

## Folder map

- `a7do_core/core/` — engine loop, state, event types
- `a7do_core/physics/` — Sandy’s Law gates, trap transitions
- `a7do_core/square/` — square micro-world primitives
- `a7do_core/sled/` — SLED signal adapters
- `a7do_core/perception/` — sound/vision stubs, feature extraction
- `a7do_core/cognition/` — patterns, mind-map, attention, decoherence
- `a7do_core/emotion/` — drives, affect, regulation
- `a7do_core/policy/` — action selection
- `a7do_core/storage/` — persistence: ledger, snapshots
- `a7do_core/utils/` — utilities
- `a7do_core/tests/` — smoke tests

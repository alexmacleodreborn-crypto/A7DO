from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass
class SLEDAdapter:
    """Convert SLED room outputs into an observation channel.

    In the full SLED system, rooms (Reception, Sales, Accounts, etc.) produce
    signals like sentiment, volatility, watchlist triggers, etc.

    Here we keep it generic: pass a dict in, get a dict out.
    """

    def normalize(self, room_signals: Dict[str, float]) -> Dict[str, float]:
        # Normalize into 0..1 range where possible
        out: Dict[str, float] = {}
        for k, v in room_signals.items():
            try:
                x = float(v)
            except Exception:
                continue
            out[k] = max(0.0, min(1.0, x))
        return out

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

from a7do_core.core.types import Regime, TrapState


@dataclass
class TrapParams:
    """Lightweight gate parameters.

    This is a runnable approximation of the Sandy’s-Law-style gate you’ve been using
    (trap → transition → escape), expressed in terms of:

    - Z: trap strength (0 open → 1 locked)
    - Sigma: entropy export (information outflow capacity)
    - K: portal score (transition trigger)

    The intent is NOT to "hard-code knowledge" but to provide a *physics-like*
    constraint layer that controls exploration, memory commits, and safety.
    """

    # Portal thresholds (tune/fit later)
    K_pre: float = 1.45
    K_zeno: float = 1.51

    # Expiry threshold: when repeated losses imply collapse/"battery break"
    expiry_loss_factor: float = 40.0


def compute_sigma(features: Dict[str, float]) -> float:
    """Estimate entropy export Σ from features.

    Convention:
    - novelty↑ increases Σ (more information escaping)
    - stability↑ decreases Σ (less new info)

    Expected feature keys (if present):
    - novelty (0..1)
    - signal_power (0..1)
    """
    novelty = float(features.get("novelty", 0.0))
    power = float(features.get("signal_power", 0.0))
    # small floor to avoid zeroing
    return max(1e-6, 0.2 * novelty + 0.8 * power)


def compute_Z(features: Dict[str, float]) -> float:
    """Estimate trap strength Z from features.

    Convention:
    - coherence↑ increases Z (system holds structure)
    - fragmentation↑ decreases Z (system opens/leaks)

    Expected feature keys (if present):
    - coherence (0..1)
    - fragmentation (0..1)
    """
    coherence = float(features.get("coherence", 0.0))
    fragmentation = float(features.get("fragmentation", 0.0))
    Z = 0.15 + 0.85 * coherence - 0.65 * fragmentation
    return float(min(0.999, max(0.0, Z)))


def compute_K(Z: float, Sigma: float) -> float:
    """Compute a portal score K.

    This is a simple monotone mapping:
    - Higher Σ (export pressure) pushes K up
    - Higher Z (lock-in) pushes K down

    In your earlier testbeds, K≈1.0 is baseline, K≈1.45 pre-transition,
    K≈1.51 Zeno.
    """
    # baseline 1.0 plus "pressure" term
    return 1.0 + 0.9 * Sigma - 0.4 * Z


def classify_regime(K: float, loss_per_event: float, params: TrapParams) -> Regime:
    """Regime classifier (Drift → Transition → Zeno/Expired)."""
    if loss_per_event >= params.expiry_loss_factor:
        return Regime.EXPIRED
    if K >= params.K_zeno:
        return Regime.ZENO
    if K >= params.K_pre:
        return Regime.TRANSITION
    return Regime.CLASSICAL


def step_trap_state(
    t: int,
    features: Dict[str, float],
    loss_per_event: float,
    params: TrapParams,
) -> TrapState:
    """Compute TrapState from features + loss signal."""
    Sigma = compute_sigma(features)
    Z = compute_Z(features)
    K = compute_K(Z=Z, Sigma=Sigma)
    regime = classify_regime(K=K, loss_per_event=loss_per_event, params=params)
    notes = {
        "loss_per_event": float(loss_per_event),
        "inputs": dict(features),
    }
    return TrapState(t=t, Z=Z, Sigma=Sigma, K=K, regime=regime, notes=notes)


def effective_evolution_rate(Z: float, Sigma: float, C: float = 1.0) -> float:
    """Sandy’s-Law-style effective evolution multiplier.

    Mirrors the worked-example pattern where evolution accelerates when
    escape channels open: rate ~ C * (1 - Z) * Σ.
    """
    return float(C * (1.0 - Z) * Sigma)


def transition_flags(prev: TrapState, cur: TrapState, params: TrapParams) -> Dict[str, bool]:
    """Convenience transition flags used by memory/policy."""
    return {
        "crossed_pre": prev.K < params.K_pre <= cur.K,
        "crossed_zeno": prev.K < params.K_zeno <= cur.K,
        "entered_zeno": prev.regime != Regime.ZENO and cur.regime == Regime.ZENO,
        "entered_expired": prev.regime != Regime.EXPIRED and cur.regime == Regime.EXPIRED,
        "exited_zeno": prev.regime == Regime.ZENO and cur.regime != Regime.ZENO,
    }

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

import math

from a7do_core.core.types import Pattern


def _l1(a: Dict[str, float], b: Dict[str, float]) -> float:
    keys = set(a) | set(b)
    return float(sum(abs(a.get(k, 0.0) - b.get(k, 0.0)) for k in keys))


@dataclass
class PatternBank:
    """Stores learned patterns and updates persistence.

    Patterns are keyed by coarse quantization of feature-space.
    """

    dist_threshold: float = 0.25
    persistence_tau: float = 50.0  # time constant for persistence

    def __post_init__(self) -> None:
        self._patterns: Dict[str, Pattern] = {}

    def _quant_key(self, feats: Dict[str, float]) -> str:
        # coarse binning to avoid overfitting
        bins: List[str] = []
        for k in sorted(feats.keys()):
            v = feats[k]
            q = int(max(0, min(9, math.floor(v * 10.0))))
            bins.append(f"{k}:{q}")
        return "|".join(bins)

    def update(self, t: int, feats: Dict[str, float]) -> Tuple[List[Pattern], List[Pattern]]:
        """Update or create pattern.

        Returns (new_patterns, updated_patterns)
        """
        key = self._quant_key(feats)
        new: List[Pattern] = []
        updated: List[Pattern] = []

        if key not in self._patterns:
            p = Pattern(
                key=key,
                centroid=dict(feats),
                support=1,
                persistence=0.0,
                created_t=t,
                last_seen_t=t,
                decohered=False,
            )
            self._patterns[key] = p
            new.append(p)
            return new, updated

        p = self._patterns[key]
        # centroid update (running average)
        p.support += 1
        for k, v in feats.items():
            prev = p.centroid.get(k, v)
            p.centroid[k] = prev + (v - prev) / float(p.support)
        dt = max(1, t - p.last_seen_t)
        p.last_seen_t = t

        # persistence rises with repeated encounters and time proximity
        # (simple leaky integrator)
        p.persistence = float(
            1.0 - math.exp(-p.support / max(1.0, self.persistence_tau))
        )
        updated.append(p)
        return new, updated

    def all_patterns(self) -> List[Pattern]:
        return list(self._patterns.values())

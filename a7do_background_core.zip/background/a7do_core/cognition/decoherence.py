from __future__ import annotations

from dataclasses import dataclass
from typing import List

from a7do_core.core.types import Pattern, Regime


@dataclass
class DecoherenceModel:
    """Turns 'soft' patterns into 'classical' concepts.

    Idea: A pattern decoheres (locks in) when it is both
    - persistent enough, and
    - learned under a sufficiently stable (non-ZENO) regime

    This is intended to mirror your "gravitational persistence of decohered systems" thread: once decohered, it becomes hard to erase.
    """

    persistence_threshold: float = 0.6

    def apply(self, patterns: List[Pattern], regime: Regime) -> List[Pattern]:
        changed: List[Pattern] = []
        if regime in (Regime.ZENO, Regime.EXPIRED):
            # do not lock in during collapse
            return changed
        for p in patterns:
            if (not p.decohered) and p.persistence >= self.persistence_threshold:
                p.decohered = True
                changed.append(p)
        return changed

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

from a7do_core.core.types import Pattern


@dataclass
class MindMap:
    """A simple concept graph built from co-occurrence.

    Nodes are decohered patterns; edges reflect temporal adjacency.
    """

    edges: Dict[Tuple[str, str], float] = field(default_factory=dict)
    last_node: str | None = None

    def observe(self, p: Pattern) -> None:
        if not p.decohered:
            return
        if self.last_node is not None:
            a = self.last_node
            b = p.key
            if a == b:
                return
            key = (a, b) if a < b else (b, a)
            self.edges[key] = float(self.edges.get(key, 0.0) + 1.0)
        self.last_node = p.key

    def top_edges(self, n: int = 10) -> List[Tuple[Tuple[str, str], float]]:
        return sorted(self.edges.items(), key=lambda kv: kv[1], reverse=True)[:n]

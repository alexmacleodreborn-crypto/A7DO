from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List

from a7do_core.core.types import Pattern, TrapState


@dataclass
class Ledger:
    """Append-only memory log.

    Keeps snapshots of trap state and pattern commits.
    """

    trap_log: List[TrapState] = field(default_factory=list)
    pattern_events: List[Dict[str, Any]] = field(default_factory=list)

    def log_trap(self, trap: TrapState) -> None:
        self.trap_log.append(trap)

    def commit_pattern(self, p: Pattern, reason: str) -> None:
        self.pattern_events.append({
            "t": p.last_seen_t,
            "key": p.key,
            "persistence": p.persistence,
            "decohered": p.decohered,
            "reason": reason,
        })

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np


@dataclass
class SquareCell:
    x: int
    y: int
    value: float = 0.0
    tags: Dict[str, float] = field(default_factory=dict)


@dataclass
class SquareWorld:
    """Minimal square microscopic world.

    This is where A7DO learns persistence/clustering without being told what
    anything *is*. It only sees numeric surfaces and local statistics.
    """

    width: int = 32
    height: int = 32
    grid: np.ndarray = field(init=False)
    t: int = 0

    def __post_init__(self) -> None:
        self.grid = np.zeros((self.height, self.width), dtype=np.float32)

    def inject_pattern(self, kind: str = "blob", strength: float = 1.0) -> None:
        """Inject a synthetic structure (for tests)."""
        rng = np.random.default_rng(self.t + 123)
        if kind == "blob":
            cx, cy = rng.integers(0, self.width), rng.integers(0, self.height)
            rr = rng.integers(2, max(3, min(self.width, self.height)//6))
            for y in range(self.height):
                for x in range(self.width):
                    if (x - cx) ** 2 + (y - cy) ** 2 <= rr ** 2:
                        self.grid[y, x] += float(strength)
        elif kind == "stripe":
            y = int(rng.integers(0, self.height))
            self.grid[y, :] += float(strength)
        elif kind == "noise":
            self.grid += rng.normal(0.0, 0.1 * strength, size=self.grid.shape)
        else:
            raise ValueError(f"Unknown pattern kind: {kind}")

    def step(self) -> None:
        """Advance microscopic dynamics (diffusion + decay)."""
        self.t += 1
        # simple diffusion
        g = self.grid
        g2 = g.copy()
        g2[1:, :] += 0.02 * g[:-1, :]
        g2[:-1, :] += 0.02 * g[1:, :]
        g2[:, 1:] += 0.02 * g[:, :-1]
        g2[:, :-1] += 0.02 * g[:, 1:]
        self.grid = 0.96 * g2  # decay

    def stats(self) -> Dict[str, float]:
        """Return simple world statistics used as features."""
        g = self.grid
        power = float(np.mean(np.abs(g)))
        var = float(np.var(g))
        # coherence proxy: high variance with spatial smoothness implies structure
        grad = np.mean(np.abs(np.diff(g, axis=0))) + np.mean(np.abs(np.diff(g, axis=1)))
        grad = float(grad)
        coherence = float(1.0 / (1.0 + grad))
        return {
            "signal_power": min(1.0, power),
            "variance": min(1.0, var),
            "coherence": min(1.0, coherence),
        }

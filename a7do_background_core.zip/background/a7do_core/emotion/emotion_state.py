from __future__ import annotations

from dataclasses import dataclass

from a7do_core.core.types import Regime, TrapState


@dataclass
class EmotionState:
    """Regulatory signals.

    Not human labels; just scalars that gate exploration vs caution.
    """

    arousal: float = 0.2
    valence: float = 0.0
    confidence: float = 0.2

    def update(self, trap: TrapState) -> None:
        # Arousal rises near transitions and with high Σ (lots happening)
        if trap.regime == Regime.TRANSITION:
            self.arousal = min(1.0, self.arousal + 0.1)
        elif trap.regime == Regime.CLASSICAL:
            self.arousal = max(0.0, self.arousal - 0.03)
        elif trap.regime in (Regime.ZENO, Regime.EXPIRED):
            self.arousal = min(1.0, self.arousal + 0.2)

        # Valence: positive when stable with good export, negative when ZENO-like
        self.valence = float((trap.Sigma - 0.5) - 0.5 * (trap.Z - 0.5))
        self.valence = max(-1.0, min(1.0, self.valence))

        # Confidence: grows with stability and moderate Σ, shrinks in ZENO
        if trap.regime == Regime.CLASSICAL:
            self.confidence = min(1.0, self.confidence + 0.02)
        elif trap.regime == Regime.TRANSITION:
            self.confidence = max(0.0, self.confidence - 0.01)
        else:
            self.confidence = max(0.0, self.confidence - 0.1)

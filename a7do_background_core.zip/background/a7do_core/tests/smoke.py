from __future__ import annotations

from a7do_core.core.engine import A7DOEngine
from a7do_core.core.types import Observation
from a7do_core.square.square_world import SquareWorld
from a7do_core.sled.sled_adapter import SLEDAdapter


def main() -> None:
    world = SquareWorld(width=24, height=24)
    engine = A7DOEngine()
    sled = SLEDAdapter()

    # Simulate: stable -> transition -> zeno-like -> recover
    for t in range(1, 101):
        if t in (10, 20, 30):
            world.inject_pattern("blob", strength=1.0)
        if t == 60:
            # push toward collapse
            engine.set_loss_per_event(45.0)
        if t == 80:
            engine.set_loss_per_event(0.0)

        world.step()
        square_stats = world.stats()

        sled_signals = sled.normalize({"sentiment": 0.4 + 0.2 * (t % 5) / 5.0})

        obs = Observation(t=t, channels={"square": square_stats, "sled": sled_signals})
        out = engine.step(obs)

        if t % 20 == 0:
            print(
                f"t={t:03d} regime={out.trap.regime.value:<10} Z={out.trap.Z:.3f} Σ={out.trap.Sigma:.3f} K={out.trap.K:.3f} action={out.action.name}"
            )

    print(f"patterns: {len(engine.pattern_bank.all_patterns())}")
    print(f"decohered: {sum(1 for p in engine.pattern_bank.all_patterns() if p.decohered)}")
    print(f"mindmap edges: {len(engine.mindmap.edges)}")


if __name__ == "__main__":
    main()

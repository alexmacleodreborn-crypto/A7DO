from __future__ import annotations

from dataclasses import dataclass
from typing import Dict

from a7do_core.core.types import FeatureVector, Observation


@dataclass
class FeatureExtractor:
    """Converts raw observations into a numeric feature dictionary.

    This is intentionally transparent: no deep nets, no hidden priors.
    Replace/extend with actual vision/audio pipelines later.
    """

    def extract(self, obs: Observation) -> FeatureVector:
        f: Dict[str, float] = {}

        # 1) Square-world stats (if present)
        if "square" in obs.channels and isinstance(obs.channels["square"], dict):
            for k, v in obs.channels["square"].items():
                try:
                    f[k] = float(v)
                except Exception:
                    continue

        # 2) SLED / room signals (if present)
        if "sled" in obs.channels and isinstance(obs.channels["sled"], dict):
            # treat as just another numeric stream
            for k, v in obs.channels["sled"].items():
                if isinstance(v, (int, float)):
                    f[f"sled_{k}"] = float(v)

        # 3) Novelty is computed as "1 - predictability" placeholder
        # If caller provides novelty, we keep it.
        if "novelty" not in f:
            f["novelty"] = min(1.0, max(0.0, f.get("variance", 0.0)))

        # 4) Fragmentation proxy (high novelty + low coherence)
        if "fragmentation" not in f:
            f["fragmentation"] = min(1.0, max(0.0, f["novelty"] * (1.0 - f.get("coherence", 0.0))))

        return FeatureVector(t=obs.t, values=f)

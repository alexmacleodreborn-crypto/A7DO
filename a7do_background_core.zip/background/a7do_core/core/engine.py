from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

from a7do_core.core.types import Action, Observation, StepResult, TrapState
from a7do_core.emotion.emotion_state import EmotionState
from a7do_core.perception.feature_extractor import FeatureExtractor
from a7do_core.physics.trap_transitions import TrapParams, step_trap_state, transition_flags
from a7do_core.cognition.patterns import PatternBank
from a7do_core.cognition.decoherence import DecoherenceModel
from a7do_core.cognition.mindmap import MindMap
from a7do_core.policy.action_policy import ActionPolicy
from a7do_core.storage.ledger import Ledger


@dataclass
class A7DOEngine:
    """Headless A7DO loop.

    Pipeline
    --------
    Observation -> FeatureVector -> TrapState -> Patterns -> Decoherence -> MindMap -> Emotion -> Action
    """

    trap_params: TrapParams = field(default_factory=TrapParams)
    feature_extractor: FeatureExtractor = field(default_factory=FeatureExtractor)
    pattern_bank: PatternBank = field(default_factory=PatternBank)
    decoherence: DecoherenceModel = field(default_factory=DecoherenceModel)
    mindmap: MindMap = field(default_factory=MindMap)
    emo: EmotionState = field(default_factory=EmotionState)
    policy: ActionPolicy = field(default_factory=ActionPolicy)
    ledger: Ledger = field(default_factory=Ledger)

    _prev_trap: Optional[TrapState] = None
    _loss_per_event: float = 0.0

    def set_loss_per_event(self, x: float) -> None:
        """External loss signal (e.g., Zeno-cell collapse metric, errors, injuries, drawdown)."""
        self._loss_per_event = float(max(0.0, x))

    def step(self, obs: Observation) -> StepResult:
        feats = self.feature_extractor.extract(obs)

        trap = step_trap_state(
            t=obs.t,
            features=feats.values,
            loss_per_event=self._loss_per_event,
            params=self.trap_params,
        )

        if self._prev_trap is None:
            flags = {"crossed_pre": False, "crossed_zeno": False, "entered_zeno": False, "entered_expired": False, "exited_zeno": False}
        else:
            flags = transition_flags(self._prev_trap, trap, self.trap_params)
        self._prev_trap = trap

        new_p, upd_p = self.pattern_bank.update(t=obs.t, feats=feats.values)
        changed = self.decoherence.apply(self.pattern_bank.all_patterns(), trap.regime)

        # Mindmap observes only decohered nodes
        for p in changed:
            self.mindmap.observe(p)

        # Commit patterns when they decohere or on meaningful boundary crossings
        for p in changed:
            self.ledger.commit_pattern(p, reason="decohered")
        if flags.get("crossed_pre"):
            self.ledger.pattern_events.append({"t": obs.t, "event": "crossed_pre"})
        if flags.get("crossed_zeno"):
            self.ledger.pattern_events.append({"t": obs.t, "event": "crossed_zeno"})

        self.emo.update(trap)
        action = self.policy.decide(trap, self.emo)

        self.ledger.log_trap(trap)

        return StepResult(obs=obs, features=feats, trap=trap, new_patterns=new_p, action=action)

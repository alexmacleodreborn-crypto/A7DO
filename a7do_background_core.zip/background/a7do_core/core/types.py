from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple


class Regime(str, Enum):
    """High-level operating regime.

    Regime is computed from Sandy's Law style gating: (Z, Σ, K) and transition flags.
    """

    CLASSICAL = "CLASSICAL"          # stable, low novelty, low risk
    TRANSITION = "TRANSITION"        # near boundary, exploratory
    ZENO = "ZENO"                    # collapse / runaway (avoid)
    EXPIRED = "EXPIRED"              # system no longer viable (stop/reset)


@dataclass(frozen=True)
class Observation:
    """Single sensory sample.

    `channels` holds arbitrary structured payloads (vision/sound/text/market/room signals).
    """

    t: int
    channels: Dict[str, Any]


@dataclass
class FeatureVector:
    """Derived numeric features used for patterning and gating."""

    t: int
    values: Dict[str, float]


@dataclass
class TrapState:
    """Sandy's Law inspired macrostate used by cognition & policy."""

    t: int
    Z: float  # trap strength
    Sigma: float  # entropy export
    K: float  # portal / transition score
    regime: Regime
    notes: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Pattern:
    """A detected repeated structure in feature-space."""

    key: str
    centroid: Dict[str, float]
    support: int
    persistence: float
    created_t: int
    last_seen_t: int
    decohered: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Action:
    """Proposed action by policy."""

    name: str
    params: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0


@dataclass
class StepResult:
    obs: Observation
    features: FeatureVector
    trap: TrapState
    new_patterns: List[Pattern]
    action: Action

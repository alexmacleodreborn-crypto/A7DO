from __future__ import annotations

from dataclasses import dataclass

from a7do_core.core.types import Action, Regime, TrapState
from a7do_core.emotion.emotion_state import EmotionState


@dataclass
class ActionPolicy:
    """Selects next action.

    Actions are intentionally primitive; higher-level skills can be layered later.
    """

    def decide(self, trap: TrapState, emo: EmotionState) -> Action:
        if trap.regime == Regime.EXPIRED:
            return Action(name="RESET", confidence=1.0)
        if trap.regime == Regime.ZENO:
            return Action(name="HOLD", params={"reason": "zeno"}, confidence=0.9)

        # Exploration increases in transition regime, if confidence isn't collapsing
        if trap.regime == Regime.TRANSITION and emo.confidence > 0.15:
            return Action(name="EXPLORE", params={"step": 1}, confidence=0.6)

        # Default: observe more
        return Action(name="OBSERVE", confidence=0.5)
